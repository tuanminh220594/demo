# WinProdKeyFinder
Windows Product Key Finder written in C#.

This app is written in C# and is for all who need or want to get Windows Product Key Number from running or offline installation of Windows. 

Browse the code if you want to get idea how to retreive and decode Windows Product Key Number in .NET/C#.

This key finder supports both old (up to Windows 7) and new (Windows 8 and up) product key algorithms.

Since version 1.3 it supports parsing DigitalProductId exported from registry so it is now possible to decode Windows Product Key Number even from "offline" Windows installations.
